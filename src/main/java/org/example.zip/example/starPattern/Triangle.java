package org.example.starPattern;

public class Triangle {
}
